package com.bankingApplication.login.bankingApplication;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*Recruitment Assignment for Backend Development Problem Statement: 
 	
 	Design a simple credit/debit wallet along with the basic interface. 
	When logged in, the system should be able to depict the following functionalities: Mandatory Functionalities: 
	1. Users are able to see the current balance. 
	2. Users are able to add money. 
	3. Users are able to withdraw money. 
	Optional Functionality: Users can see the history of transactions. (Use any in memory database or any SQL database for this question).
 	Make UI if possible, UI would be a plus point. Technologies used: (Explicitly use Java and frameworks related to Java, any DB and 
 	Follow Design pattern). 


 */

@RestController
@CrossOrigin("http://localhost:4200/")
@RequestMapping("bank")
public class BankController {

	@Autowired
	SessionFactory factory;
	double balance = 0;
	String name = null;

//	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//	LocalDateTime now = LocalDateTime.now();

	@GetMapping("accountbalance/{accnum}/{pass}")
	public double accountBalance(@PathVariable int accnum, @PathVariable String pass) {
		Session session = factory.openSession();
		Bank bank = session.load(Bank.class, accnum);
		balance = bank.getCurrentbalance();
		return balance;
	}

	@GetMapping("login/{accnum}")
	public Bank loginAccount(@PathVariable int accnum) {
		Session session = factory.openSession();
		Bank bank = session.load(Bank.class, accnum);

		return bank;
	}

	@PostMapping("credit/{accnum}/{pass}/{cbal}")
	public double creditbalance(@PathVariable int accnum, @PathVariable String pass, @PathVariable int cbal) {
		double credit = 0;
		Session session = factory.openSession();
		Bank bank = session.load(Bank.class, accnum);
		Transaction transaction = session.beginTransaction();
		if (accnum == bank.getAccountnumber() && pass.equals(bank.getPassword())) {
			double temp = bank.getCurrentbalance();
			credit = bank.getCurrentbalance() + cbal;
			bank.setCurrentbalance(credit);
			bank.setCredit(cbal);

		}
		session.save(bank);
		transaction.commit();
		return credit;
	}

	@PostMapping("withdraw/{accnum}/{pass}/{wbal}")
	public double withdrawbalance(@PathVariable int accnum, @PathVariable String pass, @PathVariable int wbal) {
		double withdraw = 0;
		Session session = factory.openSession();
		Bank bank = session.load(Bank.class, accnum);
		Transaction transaction = session.beginTransaction();
		if (accnum == bank.getAccountnumber()) {
			if (wbal >= 0) {
				double temp = bank.getCurrentbalance();
				withdraw = temp - wbal;
				bank.setCurrentbalance(withdraw);
				bank.setWithdrawbalance(wbal);
			} else {
				return 0.0;
			}

		}
		session.save(bank);
		transaction.commit();
		return withdraw;
	}

}
