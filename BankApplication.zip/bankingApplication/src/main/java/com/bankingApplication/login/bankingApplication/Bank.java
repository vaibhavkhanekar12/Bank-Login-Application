package com.bankingApplication.login.bankingApplication;


import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Bank {

	@Id
	private int accountnumber;
	private String customername;
	private double currentbalance;
	private double credit;
	private double withdrawbalance;
	private String password;

	public Bank() {
		super();
	}

	public Bank(int accountnumber, String customername, double currentbalance,double credit, double withdrawbalance,String password) {
		super();
		this.accountnumber = accountnumber;
		this.customername = customername;
		this.currentbalance = currentbalance;
		this.credit = credit;
		this.withdrawbalance = withdrawbalance;
		this.password = password;

	}

	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public double getCurrentbalance() {
		return currentbalance;
	}

	public void setCurrentbalance(double currentbalance) {
		this.currentbalance = currentbalance;
	}

	public double getWithdrawbalance() {
		return withdrawbalance;
	}

	public void setWithdrawbalance(double withdrawbalance) {
		this.withdrawbalance = withdrawbalance;
	}
	
	public double getCredit() {
		return credit;
	}

	public void setCredit(double credit) {
		this.credit = credit;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Bank [accountnumber=" + accountnumber + ", customername=" + customername + ", currentbalance="
				+ currentbalance + ", credit=" + credit + ", withdrawbalance=" + withdrawbalance + ", password="
				+ password + "]";
	}

	

}
